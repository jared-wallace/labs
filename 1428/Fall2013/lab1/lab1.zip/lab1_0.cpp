/*
 * lab1_0.cpp
 * Matt Wallace
 * Lab 1
 * 9/1/12
 * Prints a line to the console, uses literals and variables
 */
using namespace std;

int main()
{
   int age = 32;
   double years = 5;

   cout << "Hello class, I am Jared Wallace. I am " << age << " years old ";
   cout << "and I have been in school for " << years << " years." << endl;
   return 0;
}
