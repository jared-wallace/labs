/*
 * lab1_1.cpp
 * Matt Wallace
 * Lab 0
 * 9/1/12
 * Outputs one line with a mix of string literals and variables
 */
#include<iostream>
#include<string>

using namespace std;

int main()
{
   string favorite = "python";
   string common = "c++"

   cout << "My favorite programming language is " << favoite;
   cout << ", but I usually program in " << comon << "." << endl;
   return 0;
}
