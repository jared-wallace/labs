/*
 * File: input.cpp
 * Author: 
 * 
 * This program demontrates simple file input.
 */

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

int main() 
{

   /* Declare your variables here at the top. This program requires
    * lots of variables.  Use extra blank lined in order to logically
    * separate groups of variables */


   /* you will need to open the file "input.txt", don't forget to 
    * verify that the file was succesfully opened before moving on */


   /* Get the grades for student one */

   /* Get the grades for student two */

   /* Get the grades for student three */


   /* Calculate the averages for each student */


   /* Calculate the overall average */


   /* Pring the grade report */


   return 0;
}
